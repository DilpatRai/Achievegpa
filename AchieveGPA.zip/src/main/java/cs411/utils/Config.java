package cs411.utils;

import java.awt.*;

public class Config {
    // Color: #30354c
    public static Color PRIMARY_COLOR = new Color(48, 53, 76);
}
